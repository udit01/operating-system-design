#include "types.h"
#include "stat.h"
#include "user.h"
 
int
main(void)
{
  printf(1, "####\n# A user program/function which could be executed in xv6.\n# Developer: Udit Jain\n####\n");
  exit();
}