#include "types.h"
#include "stat.h"
#include "user.h"

int ps(void);

int main(void){
    ps();
    exit();
}